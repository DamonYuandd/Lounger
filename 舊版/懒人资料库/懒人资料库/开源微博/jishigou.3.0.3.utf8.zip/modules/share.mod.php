<?php

/*******************************************************************

 * [JishiGou] (C)2005 - 2099 Cenwor Inc.

 *

 * This is NOT a freeware, use is subject to license terms

 *

 * @Package JishiGou $

 *

 * @Filename share.mod.php $

 *

 * @Author http://www.jishigou.net $

 *

 * @Date 2011-09-28 19:16:47 424998998 1881735469 5961 $

 *******************************************************************/





/**
 * 站外调用
 *
 * @author 狐狸<foxis@qq.com>
 * @package jishigou.net
 */
 

if(!defined('IN_JISHIGOU'))
{
    exit('invalid request');
}

class ModuleObject extends MasterObject
{
	
	function ModuleObject($config)
	{
		$this->MasterObject($config);	
		
		Load::logic('topic');
		$this->TopicLogic = new TopicLogic($this);
		
		$this->CacheConfig = ConfigHandler::get('cache');
		
		
		$this->Execute();
	}

	
		

	function Execute()
	{
		switch($this->Code)
		{
			case 'share':
				$this->ShareLink();
				break;
			case 'show':
				$this->Show();
				break;
			case 'doshare':
				$this->DoShareLink();
				break;
			case 'endshare':
				$this->EndShare();
				break;
			case 'doshare':
				$this->DoShareLink();
				break;
			case 'recommend':
				$this->iframe_recommend();
				break;
			default:
				$this->Main();
				break;
		}
		
		exit;
	}
	
		function Main()
	{ 
		
	die('建设中。。。');
	
	}
	
		function ShareLink()
	{ 

		$action = 'index.php?mod=share&code=doshare';
	
		$url     = $this->Get['url'];
		$sbuject = array_iconv('utf-8',$this->Config['charset'],$this->Get['t']);
		
		$content = $sbuject.' '.$url;
		
		$return_url = $_SERVER["QUERY_STRING"]; 
	
		include  $this->TemplateHandler->Template('share');
	
	}
	
		function DoShareLink()
	{	
		$action = 'index.php?mod=share&code=doshare';
		
		extract($this->Get);
		extract($this->Post);
	
		        $content = trim(strip_tags((string) $this->Post['content']));
        
        		$filter_msg = filter($content);
		if(!empty($filter_msg)){ 	
          $filter_msg = str_replace("\'",'',$filter_msg);
        }
		
	 	        $content_length = strlen($content);
        if ($content_length < 2){
            $filter_msg =  "内容不允许为空";
        }
   		
        		$return = $this->TopicLogic->Add($content);
		
		if(is_array($return))
		{	
			$this->Messager(NULL,"{$this->Config['site_url']}/index.php?mod=share&code=endshare");
		}
		else
		{	
						$content = trim(strip_tags((string) $this->Post['return_content']));	
						$error = $return ? $return : $filter_msg;	
			include  $this->TemplateHandler->Template('share');	
		}
	}
	
		function EndShare() {
		
		include  $this->TemplateHandler->Template('share');
	}
	
	
	
		function iframe_recommend()
	{	
		

		$ids = (int) $this->Get['ids'];
		
				$sql = " select * from `".TABLE_PREFIX."share` where `id` = '{$ids}' ";
    	$query = $this->DatabaseHandler->Query($sql);
    	$sharelist = $query->GetRow();
    	
		
    			$share = @unserialize($sharelist['show_style']);
		
		$topic_charset = $share['topic_charset'];

				
    	if ($sharelist['nickname']) 
    	{	
    		$nickname = $sharelist['nickname'];
    		
        	if(!empty($nickname))
    		{
    			$nickname = explode('|',$nickname);
    			
    			$sql = "select `uid`,`nickname` from `".TABLE_PREFIX."members` where  `nickname` in ('".implode("','",$nickname)."')";
    			$query = $this->DatabaseHandler->Query($sql);
    			$uids = array();
    			while ($row = $query->GetRow())
    			{
    				$uids[$row['uid']] = $row['uid'];
    			}
    			
    			if($uids)
    			{   
    				
    				$user_topic_list = " `uid` in ('".implode("','",$uids)."') and ";
    				
    				
    			} else{
    			
    				echo('相关用户不存在，请重新指定。');die();
    			}
    		
    		}
    	}
		
		
		
    	
    	if ($sharelist['tag']) 
    	{	
    		$tag  = $sharelist['tag'];
    	
        	if(!empty($tag))
        	{
        		$tagname = explode('|',$tag);
        
        		$sql = "select * from `".TABLE_PREFIX."tag` where  `name` in ('".implode("','",$tagname)."')";
        		$query = $this->DatabaseHandler->Query($sql);
        		$tagids = array();
        		while ($row = $query->GetRow())
        		{
        			$tagids[$row['id']] = $row['id'];
        		}
	
        		if($tagids)
        		{
        			$tag_where_list = " where `tag_id` in ('".implode("','",$tagids)."') ";
        		} 
        	}
     
        	    		$sql = "select `item_id`,`tag_id` from `".TABLE_PREFIX."topic_tag` {$tag_where_list} order by `dateline` desc limit 0,{$share['limit']}";
    		$query = $this->DatabaseHandler->Query($sql);
    		$tids = array();
    		while ($row = $query->GetRow())
    		{
    			$tids[$row['item_id']] = $row['item_id'];
    		}
    		
    		if($tids)
    		{
    			$tag_condition = "`tid` in  ('".implode("','",$tids)."')";
    		} 
        	
    	}
		
    			if($tag_condition)
		{
			$condition = $tag_condition ;	
			
		} elseif($user_topic_list){
			
			$condition = " {$user_topic_list} `type` = 'first' ";
		} else {
			$condition = " `type` = 'first' ";
		}

		$where = "where {$condition} order by `dateline` desc limit 0,{$share['limit']}";
		
		
		$topic_list = $this->TopicLogic->Get($where);	

	
		if($share['topic_charset'] == 'utf-8')
		{	
			$topic_list  = array_iconv("gbk",$share['topic_charset'],$topic_list);			
		}
		
		include  $this->TemplateHandler->Template('share/sharetemp_'.$ids);
	
		$content = ob_get_contents();			
		ob_clean();
		
		$content = str_replace("'","\'",$content);
		$content = str_replace("\n", "", $content);
		$content = str_replace("\r", "", $content);
		$content = str_replace("/http", "http", $content);
		$content=preg_replace(array("/\r\n/i","/\>\s+\</","/\>\s+/","/\s+\</"),array("","><",">","<"),$content);

		echo "document.write('".$content."');";
		
		die;
		
	}

}
?>
