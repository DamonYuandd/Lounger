/**
 *	js语言处理
 *
 * @author     ~ZZ~<505171269@qq.com>
 * @version	   v1.0 $Date 2011-08-26
 */

function lang(key)
{
	var zh_cn = {
		loading:"正在载入..."
	}
	return zh_cn.loading;
}