<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>{$site_name} - {$site_intro}</title>
<link href="http://fonts.googleapis.com/css?family=Arvo" rel="stylesheet" type="text/css" />
<link href="../static/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
<div id="wrapper">
	<div id="wrapper2">
		<div id="header" class="container">
			<div id="logo">
				<h1><a href="#">{$site_name}</a></h1>
				<p>{$site_intro}</p>
			</div>
			<div id="menu">
				<ul>
					<li class="current_page_item"><a href="?">演示页面</a></li>
					<li><a href="http://www.tmdphp.com/" target="_blank">官方网站</a></li>
					<li><a href="http://www.freecsstemplates.org" target="_blank">模板来源</a></li>
				</ul>
			</div>
		</div>
		<!-- end #header -->
		<div id="page">
			<div id="content">
				<div class="post">
					<h2 class="title"><a href="#">{$blog.title}</a></h2>
					<p class="meta"><span class="date">{$blog.info.addtime}</span><span class="posted">作者 <a href="{$blog.info.weibo}" target="_blank">{$blog.info.author}</a></span></p>
					<div style="clear: both;">&nbsp;</div>
					<div class="entry">
						<p>{:nl2br( $blog['content'] )}</p>
					</div>
				</div>
				<div class="post">
					<h2 class="title"><a href="#">测试一下在模板插入图片</a></h2>
					<div style="clear: both;">&nbsp;</div>
					<div class="entry">
						<p><img src="../static/temp/image_test.jpg" alt="" width="220" height="330" /></p>
					</div>
				</div>
				
			  <div style="clear: both;">&nbsp;</div>
			</div>
			<!-- end #content -->
			<div id="sidebar">
				<ul>
				  <li>
					  <h2>关于循环</h2>
					  <ul>
                      <!--<?php
					  foreach ($links as $name => $url) {
					  ?>-->
						  <li><a href="{$url}" target="_blank">{$name}</a></li>
                      <!--<?php
					  }
					  ?>-->
					  </ul>
					</li>
				</ul>
			</div>
			<!-- end #sidebar -->
			<div style="clear: both;">&nbsp;</div>
		</div>
		<!-- end #page -->
	</div>
</div>
<?php include('inc/footer.tpl.php'); ?>
<!-- end #footer -->
<script type="text/javascript" src="../static/test.js"></script>
</body>
</html>
