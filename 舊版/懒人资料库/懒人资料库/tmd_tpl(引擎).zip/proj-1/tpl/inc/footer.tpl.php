<div id="footer-content">
	<div id="footer">
		<p>这是被包含进来的底部文件</p>
	</div>
</div>