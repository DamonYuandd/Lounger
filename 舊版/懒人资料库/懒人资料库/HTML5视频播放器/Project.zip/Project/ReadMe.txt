### HTML5VideoPlayer ###
 
===========================================================================
DESCRIPTION:
 
It is a video controller using CSS3 and HTML 5 � specifically, the HTML 5 <video> element, the HTMLMediaElement DOM interface. JavaScript is used to pause, play, mute, control volume, fullscreen mode, seek through content in real time. CSS3 is used to hide and show the playback controls.
Flash is used only whenever there´s no native H.264 support available. 

===========================================================================
BUILD REQUIREMENTS:
 
All Browsers
 
===========================================================================
PACKAGING LIST:
 
index.html -- the main HTML file to load in the browser
style.css  -- the CSS file
script.js  -- the JavaScript file
video.mp4  -- the movie used in the sample

===========================================================================
CHANGES FROM PREVIOUS VERSIONS:
 
Version 1.0
- First version.
 
===========================================================================
Copyright (C) 2010 Dario Caruso